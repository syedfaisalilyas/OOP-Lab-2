﻿using SMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS
{
    class Program
    {
        static void Main(string[] args)
        {
            Student[] s = new Student[10];
            char option;
            int count = 0;
            do
            {
                option = Menu();
                if (option == '1')
                {
                   s[count] = AddStudent();
                    count++;
                }
                else if (option == '2')
                {
                    ViewStudent(s, count);
                }
                else if (option == '3')
                {
                    TopStudent(s, count);
                }
                else if (option == '4')
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Input !");

                }
            }
            while (option != '4');
            Console.WriteLine("Press Enter to Exit");
            Console.Read();
                
        }

        static char Menu()
        {
            Console.Clear();
            char choice;
            Console.WriteLine("Press 1 for Adding Students: ");
            Console.WriteLine("Press 2 for Viewing Students: ");
            Console.WriteLine("Press 3 for Top Three Students: ");
            Console.WriteLine("Press 4 to Exit: ");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }

        static Student AddStudent()
        {
            Console.Clear();
            Student s1 = new Student();
            Console.WriteLine("Enter Name:");
            s1.name = Console.ReadLine();
            Console.WriteLine("Enter Roll Number:");
            s1.roll_no = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter CGPA:");
            s1.cgpa = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter Department:");
            s1.department = Console.ReadLine();
            Console.WriteLine("Is Hostelide (y || n):");
            s1.isHostelide = char.Parse(Console.ReadLine());
            return s1;
        }

        static void ViewStudent(Student[] s,int count)
        {
            Console.Clear();
            for(int i=0;i<count;i++)
            {
                Console.WriteLine("Name: {0} Roll Number: {1} Department: {2} IsHostelide: {3} CGPA: {4}",s[i].name,s[i].roll_no ,s[i].department,s[i].isHostelide,s[i].cgpa);
            }
            Console.WriteLine("Press any key to conntinue..");
            Console.ReadKey();
        }

        static int Largest(Student[] s,int start,int end)
        {
            int index = start;
            float large = s[start].cgpa;
            for(int x=start;x<end;x++)
            {
                if(large<s[x].cgpa)
                {
                    large = s[x].cgpa;
                    index = x;
                }
            }
            return index;
        }

        static void TopStudent(Student[] s,int count)
        {
            Console.Clear();
            if(count == 0)
            {
                Console.WriteLine("No record Present");
            }
            else if(count == 1)
            {
                ViewStudent(s, 1);
            } 
            else if(count == 2)
            {
                for(int i=0;i<2;i++)
                {
                    int index = Largest(s, i, count);
                    Student temp = s[index];
                    s[index] = s[i];
                    s[i] = temp;
                }
                ViewStudent(s, 2);
            }
            else if(count==3)
            {
                for(int i=0;i<3;i++)
                {
                    int index = Largest(s, i, count);
                    Student temp = s[index];
                    s[index] = s[i];
                    s[i] = temp;
                }
                ViewStudent(s, 3);
            }

        }
    }
}
