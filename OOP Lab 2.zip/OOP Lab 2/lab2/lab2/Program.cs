﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace lab2
{
    class Program
    {

        static void Main(string[] args)
        {
            Task1();
            Task2();
            Task3();
            Console.Read();

        }

        static void Task1()
        {
            Students s1 = new Students();
            s1.name = "Faisal";
            s1.roll_no = 63;
            s1.cgpa = 3.85F;
            Console.WriteLine("Name: {0} Roll Number: {1} CGPA: {2}", s1.name, s1.roll_no, s1.cgpa);
        }  
        static void Task2()
        {
            Students s2 = new Students();
            s2.name = "Jaffer";
            s2.roll_no = 76;
            s2.cgpa = 3.55F;
            Console.WriteLine("Name: {0} Roll Number: {1} CGPA: {2}", s2.name, s2.roll_no, s2.cgpa);
        }

        static void Task3()
        {
            Students s3 = new Students();
            Console.WriteLine("Enter Name:");
            s3.name = Console.ReadLine();
            Console.WriteLine("Enter Roll Number:");
            s3.roll_no = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter CGPA:");
            s3.cgpa =  float.Parse(Console.ReadLine());
            Console.WriteLine("Name: {0} Roll Number: {1} CGPA: {2}", s3.name, s3.roll_no, s3.cgpa);
        }


    }
}
