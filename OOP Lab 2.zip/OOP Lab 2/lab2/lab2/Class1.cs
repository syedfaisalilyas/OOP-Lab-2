﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class Students
    {
        public string name;
        public int roll_no;
        public float cgpa;
    }
}
