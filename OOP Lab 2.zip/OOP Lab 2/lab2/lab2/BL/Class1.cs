﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2.BL
{
    class Student
    {
        public string name;
        public int roll_no;
        public float cgpa;
        public char ishostelide;
        public string department;
    }
}
