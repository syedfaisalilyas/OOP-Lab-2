﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace signin_up.BL
{
    class SignIn
    {
        public string username;
        public string password;
    }
    class SignUp
    {
        public string names;
        public string usernames;
        public string password;
        public int ages;
        public string cnic;
        public string addresses;
    }
}
