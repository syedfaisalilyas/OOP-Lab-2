﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using signin_up.BL;

namespace Sign_In_And_Sign_Up
{
    internal class Program
    {
       
        static void Main(string[] args)
        {
            string option;
            do
            {
                option = Menu();
                if (option == "1")
                {
                    Sign_In();
                }
                else if (option == "2")
                {
                    Sign_Up();
                }
                else if (option == "3")
                {
                    break;
                }
            } while (option != "3");
        }
        static string Menu()
        {
            string opt;
            Console.Clear();
            Console.WriteLine("\t\t MAIN MENU");
            Console.WriteLine("");
            Console.WriteLine("1.Sign In");
            Console.WriteLine("2.Sign Up");
            Console.WriteLine("3.Exit");
            Console.Write("Your Option: ");
            opt = Console.ReadLine();
            return opt;
        }
        static void Sign_In()
        {
            Console.Clear();
            Console.WriteLine("\t\t MAIN MENU >> SIGNIN MENU");
            Console.WriteLine("");
            SignIn s1 = new SignIn();
            Console.Write("Enter Username: ");
            s1.username = Console.ReadLine();
            Console.Write("Enter Password: ");
            s1.password = Console.ReadLine();
            Check_SignIn(s1);
        }
        static void Check_SignIn(SignIn s)
        {
            Console.Clear();
            string path = "data.txt";
            StreamReader filevar = new StreamReader(path);
            string record;
            bool flag = false;
            while (!(filevar.EndOfStream))
            {
                record = filevar.ReadLine();
                string[] r = record.Split(',');
                if (s.username == r[1] && s.password == r[2])
                {
                    flag = true;
                }
            }
            filevar.Close();
            if (flag == true)
            {
                Console.WriteLine("Valid User.....");
                Console.WriteLine("SignIn Successfully....");
            }
            if (flag == false)
            {
                Console.WriteLine("Invalid User....");
            }
            Console.ReadKey();
        }
        static SignUp Sign_Up()
        {
            Console.Clear();
            Console.WriteLine("\t\t MAIN MENU >> SIGNUP MENU");
            Console.WriteLine("");
            SignUp s = new SignUp();
            Console.Write("Enter Name: ");
            s.names = Console.ReadLine();
            Console.Write("Enter UserName: ");
            s.usernames = Console.ReadLine();
            Console.Write("Enter Password: ");
            s.password = Console.ReadLine();
            Console.Write("Enter CNIC: ");
            s.cnic = Console.ReadLine();
            Console.Write("Enter Age: ");
            s.ages = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Address: ");
            s.addresses = Console.ReadLine();
            Sign_Up(s);
            return s;
        }
        static void Sign_Up(SignUp s)
        {
            string path = "data.txt";
            StreamWriter filevar = new StreamWriter(path, true);
            filevar.WriteLine(s.names + "," + s.usernames + "," + s.password + "," + s.ages + "," + s.cnic + "," + s.addresses);
            filevar.Flush();
            filevar.Close();
        }
    }
}