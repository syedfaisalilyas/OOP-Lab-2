﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product1
{
    class Program
    {
        static void Main(string[] args)
        {
            Products[] products = new Products[10];
            int choice = 0;
            int item_count = 0;
            int price = 0;
            do
            {
                choice = storeMenu();
                if (choice == '1')
                {
                    products[item_count] = add_product();
                    item_count++;
                }
                if (choice == '2')
                {
                    show_products(products, item_count);
                }
                else if (choice == '3')
                {
                    price = storeWorth(products, item_count);
                }
                else if (choice == '4')
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice! ");
                }

            }
            while (choice != '4');
        } 

 
        static char storeMenu()
        {
            char choice;
            Console.WriteLine("Press 1 to add a product ");
            Console.WriteLine("Press 2 to view products ");
            Console.WriteLine("Press 3 to see store total worth ");
            Console.WriteLine("Press 4 to exit");
            choice = char.Parse(Console.ReadLine());
            return choice;
        }
        static Products add_product()
        {
            Console.Clear();
            Products p1 = new Products();
            Console.WriteLine("Enter product ID");
            p1.ID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter product name: ");
            p1.Name = Console.ReadLine();
            Console.WriteLine("Enter product price: ");
            p1.Price = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter product category: ");
            p1.Category = Console.ReadLine();
            Console.WriteLine("Enter product brand: ");
            p1.BrandName = Console.ReadLine();
            Console.WriteLine("Enter product country: ");
            p1.Country = Console.ReadLine();
            return p1;
        }
        static void show_products(Products[] products, int count)
        {
            Console.Clear();
            if (count == 0)
            {
                Console.WriteLine("No recored present!");
            }
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Product ID: " + products[i].ID);
                Console.WriteLine("Product name: " + products[i].Name);
                Console.WriteLine("Product price: " + products[i].Price);
                Console.WriteLine("Product category: " + products[i].Category);
                Console.WriteLine("Product brand: " + products[i].BrandName);
                Console.WriteLine("Product country: " + products[i].Country);
            }
            Console.WriteLine("Enter any key to contine: ");
            Console.ReadKey();
        }
        static int storeWorth(Products[] products, int count)
        {
            int price = 0;
            for (int j = 0; j < count; j++)
            {
                price = (int)(products[j].Price + price);
            }
            return price;
        }
    }
}
