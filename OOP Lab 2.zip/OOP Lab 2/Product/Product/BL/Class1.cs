﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product1
{
    class Products
    {
        public int ID;
        public string Name;
        public float Price;
        public string Category;
        public string BrandName;
        public string Country;
    }
}
